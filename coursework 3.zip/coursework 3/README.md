# Avinam12-resit-coursework-1-cpp
name -avinam thakur
student id-23045167
github URL -https://github.com/Avinam12/Avinam12-resit-coursework-cpp.git
