#include <iostream>
#include <fstream>
#include <string>
using namespace std;

// Base class for vehicles
class Vehicle {
protected:
    string regNumber, color;

public:
    Vehicle(string regNum, string col) : regNumber(regNum), color(col) {}

    virtual void writeToFile(ofstream& file) const {
        file << "Vehicle: " << regNumber << ", " << color << endl;
    }

    virtual void display() const {
        cout << regNumber << ", " << color << endl;
    }

    virtual ~Vehicle() {}
};

// Derived class for cars
class Car : public Vehicle {
private:
    int numSeats;

public:
    Car(string regNum, string col, int seats) : Vehicle(regNum, col), numSeats(seats) {
        if (seats <= 0) throw invalid_argument("Invalid seats");
    }

    void writeToFile(ofstream& file) const override {
        file << "Car: " << regNumber << ", " << color << ", Seats: " << numSeats << endl;
    }

    void display() const override {
        cout << regNumber << ", " << color << ", Seats: " << numSeats << endl;
    }
};

// Derived class for bikes
class Bike : public Vehicle {
private:
    int engineCapacity;

public:
    Bike(string regNum, string col, int engineCap) : Vehicle(regNum, col), engineCapacity(engineCap) {
        if (engineCap <= 0) throw invalid_argument("Invalid engine");
    }

    void writeToFile(ofstream& file) const override {
        file << "Bike: " << regNumber << ", " << color << ", Engine: " << engineCapacity << "cc" << endl;
    }

    void display() const override {
        cout << regNumber << ", " << color << ", Engine: " << engineCapacity << "cc" << endl;
    }
};

// Main program
int main() {
    ofstream file("vehicles.txt", ios::app);
    if (!file) {
        cout << "Error: Can't open file\n";
        return 1;
    }

    try {
        int choice;
        cout << "1. Car\n2. Bike\nChoice: ";
        cin >> choice;
        cin.ignore();

        string regNum, color;
        cout << "Reg Number: ";
        getline(cin, regNum);
        cout << "Color: ";
        getline(cin, color);

        if (choice == 1) {
            int seats;
            cout << "Seats: ";
            cin >> seats;
            Car car(regNum, color, seats);
            car.writeToFile(file);
            cout << "Car saved\n";
            car.display();
        } else if (choice == 2) {
            int engineCap;
            cout << "Engine (CC): ";
            cin >> engineCap;
            Bike bike(regNum, color, engineCap);
            bike.writeToFile(file);
            cout << "Bike saved\n";
            bike.display();
        } else {
            cout << "Invalid choice\n";
        }
    } catch (const invalid_argument& e) {
        cout << "Error: " << e.what() << endl;
    }

    file.close();
    return 0;
}
