#include <iostream>
#include <stdexcept>
#include <string>
using namespace std;

// Custom exception for invalid time values
class InvalidTimeException : public runtime_error {
public:
    InvalidTimeException(const string& message) : runtime_error(message) {}
};

// Class to manage time with hours and minutes
class Time {
private:
    int hours;   // Hours component
    int minutes; // Minutes component

    // Validate time inputs
    void validateTime() const {
        if (hours < 0 || hours >= 24) {
            throw InvalidTimeException("Hours must be 0-23.");
        }
        if (minutes < 0 || minutes >= 60) {
            throw InvalidTimeException("Minutes must be 0-59.");
        }
    }

public:
    // Default constructor: sets time to 00:00
    Time(int h = 0, int m = 0) : hours(h), minutes(m) {
        validateTime();
    }

    // Add two time objects
    Time operator+(const Time& other) const {
        int totalMinutes = (hours + other.hours) * 60 + (minutes + other.minutes);
        int newHours = totalMinutes / 60;
        int newMinutes = totalMinutes % 60;
        return Time(newHours, newMinutes);
    }

    // Compare if this time is greater than another
    bool operator>(const Time& other) const {
        return (hours * 60 + minutes) > (other.hours * 60 + other.minutes);
    }

    // Display time in HH:MM format
    void display() const {
        cout << hours << ":" << (minutes < 10 ? "0" : "") << minutes;
    }
};

// Main program
int main() {
    try {
        // Get first time input
        int h1, m1;
        cout << "Enter first time (hours minutes): ";
        cin >> h1 >> m1;
        Time time1(h1, m1);

        // Get second time input
        int h2, m2;
        cout << "Enter second time (hours minutes): ";
        cin >> h2 >> m2;
        Time time2(h2, m2);

        // Display times
        cout << "Time 1: ";
        time1.display();
        cout << endl;
        cout << "Time 2: ";
        time2.display();
        cout << endl;

        // Add and display sum
        cout << "Sum: ";
        Time sum = time1 + time2;
        sum.display();
        cout << endl;

        // Compare times
        cout << "Comparison: Time 1 " << (time1 > time2 ? ">" : "<=") << " Time 2\n";

    } catch (const InvalidTimeException& e) {
        cout << "Error: " << e.what() << endl;
    } catch (...) {
        cout << "Error: Unexpected issue occurred.\n";
    }

    return 0;
}
