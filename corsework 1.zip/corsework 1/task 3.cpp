#include <iostream>
using namespace std;

int main() {
    char seats[5][5] = {
        {'O', 'O', 'O', 'O', 'O'},
        {'O', 'O', 'O', 'O', 'O'},
        {'O', 'O', 'O', 'O', 'O'},
        {'O', 'O', 'O', 'O', 'O'},
        {'O', 'O', 'O', 'O', 'O'}
    };
    while (true) {
        cout << "Cinema Seats:\n";
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                cout << seats[i][j] << " ";
            }
            cout << endl;
        }
        int row, col;
        cout << "Enter row (1-5, 0 to exit): ";
        cin >> row;
        cout << "Enter column (1-5, 0 to exit): ";
        cin >> col;
        if (row == 0 && col == 0) {
            cout << "Exiting...\n";
            break;
        }
        if (row < 1 || row > 5 || col < 1 || col > 5) {
            cout << "Invalid seat! Enter values between 1 and 5.\n";
            continue;
        }
        row--; col--; // Zero-based indexing
        if (seats[row][col] == 'X') {
            cout << "Seat already booked! Try another.\n";
            continue;
        }
        seats[row][col] = 'X';
        cout << "Seat booked successfully!\n";
        char more;
        cout << "Book more seats? (y/n): ";
        cin >> more;
        if (more == 'n' || more == 'N') {
            cout << "Exiting...\n";
            break;
        }
    }
    return 0;
}
