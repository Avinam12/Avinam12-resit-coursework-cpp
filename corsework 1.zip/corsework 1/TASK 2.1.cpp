#include <iostream>
using namespace std;
bool isBouncy(int num) {
    if (num < 100) return false; // Numbers below 100 NOT bouncy
    bool up = false, down = false;
    int prev = num % 10; // Start with last digit
    num /= 10;
    while (num > 0) {
        int curr = num % 10; // Get next digit
        if (curr > prev) up = true; // Check if increasing
        if (curr < prev) down = true; // Check if decreasing
        if (up && down) return true; // Bouncy if both
        prev = curr;
        num /= 10;
    }
    return false; // Not bouncy
}
int main() {
    int num;
    cout << "Enter a positive integer: ";
    cin >> num;
    if (num <= 0) {
        cout << "Invalid input! Please enter a positive number." << endl;
        return 1;
    }
    if (isBouncy(num)) {
        cout << num << " is a bouncy number." << endl;
    } else {
        cout << num << " is NOT a bouncy number." << endl;
    }
    return 0;
}
