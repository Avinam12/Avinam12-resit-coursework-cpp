#include <iostream>
using namespace std;
class DayFinder {
public:
    void showDay() {
        int day;
        cout << "Enter day of week (1-7): ";
        cin >> day;
        switch (day) {
            case 1: cout << "Sunday" << endl; break;
            case 2: cout << "Monday" << endl; break;
            case 3: cout << "Tuesday" << endl; break;
            case 4: cout << "Wednesday" << endl; break;
            case 5: cout << "Thursday" << endl; break;
            case 6: cout << "Friday" << endl; break;
            case 7: cout << "Saturday" << endl; break;
            default: cout << "Invalid day! Enter number between 1 and 7." << endl;
        }
    }
};
int main() {
    DayFinder day;
    day.showDay();
    return 0;
}
