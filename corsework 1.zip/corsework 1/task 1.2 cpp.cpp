#include <iostream>
#include <ctime>
using namespace std;

class GuessGame {
    int secret;
public:
    GuessGame() { srand(time(0)); }
    void start() {
        char difficulty;
        int range, guess;
        cout << "Welcome to the Number Guessing Game!" << endl;
        cout << "Choose your difficulty: Easy (e), Medium (m), Hard (h): ";
        cin >> difficulty;
        switch (difficulty) {
            case 'e': case 'E':
                range = 8;
                secret = rand() % range + 1;
                cout << "Guess a number between 1 and 8: ";
                cin >> guess;
                if (guess == secret)
                    cout << "Congratulations! You guessed the correct number." << endl;
                else
                    cout << "Wrong guess! The correct number was " << secret << "." << endl;
                break;
            case 'm': case 'M':
                range = 30;
                secret = rand() % range + 1;
                cout << "Guess a number between 1 and 30: ";
                cin >> guess;
                if (guess == secret)
                    cout << "Congratulations! You guessed the correct number." << endl;
                else
                    cout << "Wrong guess! The correct number was " << secret << "." << endl;
                break;
            case 'h': case 'H':
                range = 50;
                secret = rand() % range + 1;
                cout << "Guess a number between 1 and 50: ";
                cin >> guess;
                if (guess == secret)
                    cout << "Congratulations! You guessed the correct number." << endl;
                else
                    cout << "Wrong guess! The correct number was " << secret << "." << endl;
                break;
            default:
                cout << "Invalid input! Please restart the game and choose a valid difficulty." << endl;
        }
    }
};

int main() {
    GuessGame game;
    game.start();
    return 0;
}
