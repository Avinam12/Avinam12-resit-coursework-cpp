#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;

int main() {
    char titles[10][150];
    char filename[100];
    cout << "Enter filename for books (e.g., books.dat): ";
    cin.getline(filename, 100);

    cout << "Enter 10 book titles:\n";
    for (int i = 0; i < 10; i++) {
        cout << "Book " << i + 1 << ": ";
        cin.getline(titles[i], 150);
    }

    ofstream outFile(filename, ios::binary);
    if (!outFile) {
        cout << "Error saving to file!\n";
        return 1;
    }
    for (int i = 0; i < 10; i++) {
        outFile.write(titles[i], 150);
    }
    outFile.close();

    char search[150];
    cout << "\nEnter title to search: ";
    cin.getline(search, 150);

    ifstream inFile(filename, ios::binary);
    if (!inFile) {
        cout << "Error reading file!\n";
        return 1;
    }
    bool found = false;
    char temp[150];
    while (inFile.read(temp, 150)) {
        if (strcmp(temp, search) == 0) {
            found = true;
            break;
        }
    }
    inFile.close();

    if (found)
        cout << "\"" << search << "\" is in the file.\n";
    else
        cout << "\"" << search << "\" is not in the file.\n";

    return 0;
}
