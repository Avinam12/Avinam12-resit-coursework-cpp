#include <iostream>
#include <fstream>
#include <string>
#include <vector>
using namespace std;

struct Student {
    int roll;
    string name;
    int marks;
};

void validateMarks(int marks) {
    if (marks < 0 || marks > 100) {
        throw string("Marks must be 0 to 100!");
    }
}

vector<Student> readRecords(const string& filename) {
    vector<Student> students;
    ifstream inFile(filename);
    if (!inFile) {
        cout << "File not found. Initializing with sample data.\n";
        // Initialize with sample data
        students.push_back({120, "avinam", 99});
        students.push_back({101, "ram", 90});
        return students;
    }
    Student s;
    while (inFile >> s.roll >> s.name >> s.marks) {
        try {
            validateMarks(s.marks);
            students.push_back(s);
        } catch (string& e) {
            cout << "Skipping invalid record: " << e << endl;
        }
    }
    inFile.close();
    return students;
}

void writeRecords(const string& filename, const vector<Student>& students) {
    ofstream outFile(filename);
    if (!outFile) {
        cout << "Error saving to file!\n";
        return;
    }
    for (const Student& s : students) {
        outFile << s.roll << " " << s.name << " " << s.marks << endl;
    }
    outFile.close();
    cout << "Records saved successfully.\n";
}

int main() {
    string filename = "students.txt";
    vector<Student> students = readRecords(filename);

    cout << "Student Records:\n";
    if (students.empty()) {
        cout << "No records found.\n";
    } else {
        for (const Student& s : students) {
            cout << "Roll: " << s.roll << ", Name: " << s.name << ", Marks: " << s.marks << endl;
        }
    }

    while (true) {
        cout << "\nMenu:\n1. Add new record\n2. Modify record\n3. Exit\nEnter choice: ";
        int choice;
        cin >> choice;
        cin.ignore();

        if (choice == 3) {
            cout << "Exiting...\n";
            break;
        }

        if (choice == 1) {
            Student s;
            cout << "Enter roll: ";
            cin >> s.roll;
            cin.ignore();
            cout << "Enter name: ";
            getline(cin, s.name);
            cout << "Enter marks (0-100): ";
            cin >> s.marks;
            try {
                validateMarks(s.marks);
                students.push_back(s);
                cout << "Record added successfully.\n";
            } catch (string& e) {
                cout << "Error: " << e << endl;
            }
        } else if (choice == 2) {
            int roll;
            cout << "Enter roll to modify: ";
            cin >> roll;
            bool found = false;
            for (Student& s : students) {
                if (s.roll == roll) {
                    found = true;
                    cout << "Enter new marks (0-100): ";
                    cin >> s.marks;
                    try {
                        validateMarks(s.marks);
                        cout << "Record updated successfully.\n";
                    } catch (string& e) {
                        cout << "Error: " << e << endl;
                    }
                    break;
                }
            }
            if (!found) {
                cout << "Roll " << roll << " not found.\n";
            }
        } else {
            cout << "Invalid choice! Choose 1, 2, or 3.\n";
        }
    }

    writeRecords(filename, students);
    return 0;
}
